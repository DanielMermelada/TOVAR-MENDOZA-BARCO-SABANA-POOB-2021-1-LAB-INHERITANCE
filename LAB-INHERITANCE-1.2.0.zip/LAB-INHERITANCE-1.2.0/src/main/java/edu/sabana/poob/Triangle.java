package edu.sabana.poob;

public class Triangle extends Shape{
    private double side1 = 1;
    private double side2 = 1;
    private double side3 = 1;

    public Triangle(String color, double side1, double side2, double side3) {
        super(color);
        this.side1 = side1;
        this.side2 = side2;
        this.side3 = side3;
    }
    public double getPerimeter(){return this.side1 + this.side2 + this.side3;}

    public boolean isEquilateral(){
    boolean result = false;
        if(side1==side2 && side1==side3)
            result = true;
        return result;
    }

    public boolean isIsosceles(){
        boolean result = false;
        if(!isEquilateral())
            result=true;
        return result;

    }

    public double getArea(){
        int result = 0;
        if(isEquilateral())
            result = (int)(Math.round((Math.sqrt(3)/4)*Math.pow(side1,2)));
        else
            result = (int)(Math.round((side2*Math.sqrt(Math.pow(side1,2)-(Math.pow(side2,2)/4))))/2);
        return result;
    }
    public String toString(){
        String result;
        if(isEquilateral())
            result ="Is Equilateral";
        else
            result ="Is Isosceles";
        return super.toString()+ String.format(" and %s", result);
    }




}
