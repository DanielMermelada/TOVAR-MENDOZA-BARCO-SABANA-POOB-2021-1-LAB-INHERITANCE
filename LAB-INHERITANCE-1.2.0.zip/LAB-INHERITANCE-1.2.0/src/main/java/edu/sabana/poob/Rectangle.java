package edu.sabana.poob;

public class Rectangle extends Shape{
    private double width = 1;
    private double length = 1;

    public Rectangle(String color, double width, double length) {
        super(color);
        this.width = width;
        this.length = length;
    }

    @Override
    public double getArea() {
        return (int) (this.length*this.width);
    }

    @Override
    public double getPerimeter() {
        return (int) ((this.length*2)+(this.width*2));
    }
    public double getDiagonal(){return Math.round(Math.sqrt(Math.pow(this.width,2)+ Math.pow(this.width,2)));}

}
