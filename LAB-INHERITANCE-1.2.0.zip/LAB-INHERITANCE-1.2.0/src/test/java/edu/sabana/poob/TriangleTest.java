package edu.sabana.poob;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TriangleTest {
    private static Triangle t1;
    private static Triangle t2;
    private static Triangle t3;
    private static Triangle t4;

    @BeforeAll
    private static void setUp(){
        t1 = new Triangle("NONE",4,4,4);
        t2 = new Triangle("Green",8,9,8);
        t3 = new Triangle("NONE",22,22,22);
        t4 = new Triangle("Blue",7,7,7);
    }
    @Test
    public void shouldCalculateArea(){

        assertEquals(7,(int) t1.getArea());
        assertEquals(30,(int) t2.getArea());
        assertEquals(210,(int) t3.getArea());
        assertEquals(21,(int) t4.getArea());
    }
    @Test
    public void shouldCalculatePerimeter(){

        assertEquals(12, (int) t1.getPerimeter());
        assertEquals(25, (int) t2.getPerimeter());
        assertEquals(66, (int) t3.getPerimeter());
        assertEquals(21, (int) t4.getPerimeter());
    }
    @Test
    public void shouldPrintTriangle(){

        assertEquals("This is a Triangle with color NONE and Is Equilateral", t1.toString());
        assertEquals("This is a Triangle with color Green and Is Isosceles", t2.toString());
        assertEquals("This is a Triangle with color NONE and Is Equilateral", t3.toString());
        assertEquals("This is a Triangle with color Blue and Is Equilateral", t4.toString());
    }
}
