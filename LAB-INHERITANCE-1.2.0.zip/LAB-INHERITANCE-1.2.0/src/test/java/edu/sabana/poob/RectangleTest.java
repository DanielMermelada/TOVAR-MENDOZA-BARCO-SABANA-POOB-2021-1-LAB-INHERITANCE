package edu.sabana.poob;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class RectangleTest {

    private static Rectangle r1;
    private static Rectangle r2;
    private static Rectangle r3;
    private static Rectangle r4;

    @BeforeAll
    private static void setUp() {
        r1 = new Rectangle("NONE", 4, 8);
        r2 = new Rectangle("Green", 8, 12);
        r3 = new Rectangle("NONE", 22, 28);
        r4 = new Rectangle("Blue", 7, 9);
    }
    @Test
    public void shouldCalculateArea(){

        assertEquals(32,(int) r1.getArea());
        assertEquals(96,(int) r2.getArea());
        assertEquals(616,(int) r3.getArea());
        assertEquals(63,(int) r4.getArea());
    }
    @Test
    public void shouldCalculatePerimeter(){

        assertEquals(24, (int) r1.getPerimeter());
        assertEquals(40, (int) r2.getPerimeter());
        assertEquals(100, (int) r3.getPerimeter());
        assertEquals(32, (int) r4.getPerimeter());
    }
    @Test
    public void shouldCalculateDiagonal(){

        assertEquals(9, (int) r1.getDiagonal());
        assertEquals(20, (int) r2.getDiagonal());
        assertEquals(50, (int) r3.getDiagonal());
        assertEquals(16, (int) r4.getDiagonal());
    }
    @Test
    public void shouldPrintRectangle(){

        assertEquals("This is a Rectangle with color NONE and diagonal", r1.toString());
        assertEquals("This is a Rectangle with color Green and diagonal", r2.toString());
        assertEquals("This is a Rectangle with color NONE and diagonal", r3.toString());
        assertEquals("This is a Rectangle with color Blue and diagonal", r4.toString());
    }
}
